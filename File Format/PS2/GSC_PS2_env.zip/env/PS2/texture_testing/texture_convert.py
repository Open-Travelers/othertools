from PIL import Image
from struct import unpack
import math
import sys

g_pallete = []
g_image_data = bytearray(b"")

def get_size_from_sub_hdr(f, is_pallete):
	f.seek(80, 1)
	size_ = unpack('H', f.read(2))[0]
	f.seek(14, 1)
	
	if is_pallete == True:
		if (size_ == 0x8008):
			return 16
		if (size_ == 0x8080):
			return 256
		else:
			raise Exception("unsupported pallete size %d" % size_)
	
	return (size_ - 0x8000) << 4
	
def read_pallete(f, amt):
	global g_pallete
	for i in range(0, amt):
		(r, g, b, alph) = unpack('BBBB', f.read(4))
		g_pallete.append((r, g, b, alph * 2))

	

def parse_file(f):
	global g_image_data
	f.seek(2, 1)
	type = unpack('H', f.read(2))[0]
	if type != 1:
		raise Exception("texture type != 1")
	width = unpack('H', f.read(2))[0]
	#print(width)
	f.seek(9, 1)
	flags4 = unpack('B', f.read(1))[0]
	#print(flags4)
	offset_pallete = unpack('H', f.read(2))[0]
	#print(offset_pallete)
	f.seek(14, 1)
	if flags4 & 0x80:
		#contain pallete
		entries_amt = get_size_from_sub_hdr(f, True)
		
		v1 = 1
		
		if entries_amt == 16:
			v1 = 2
		
		read_pallete(f, entries_amt)
		f.seek(offset_pallete + 16)
		
		while f.tell() % 0x80 != 0:
			f.seek(16, 1)
		
		img_size = get_size_from_sub_hdr(f, False)
		g_image_data = bytearray(f.read(img_size))
		return (width, v1 * img_size // width, True)
		
	else:
		#no pallete
		while f.tell() % 0x80 != 0:
			f.seek(16, 1)
		img_size = get_size_from_sub_hdr(f, False)
		g_image_data = bytearray(f.read(img_size))
		return (width, (img_size // width) // 3, False)
		
	

def shift_array_bytes(arr, shift):
	arr_len = len(arr)
	if shift < 0:
		shift = arr_len - shift
	for i in range(arr_len - 1):
		tmp = arr[i]
		arr[i] = arr[(i+shift) % arr_len]
		arr[(i+shift) % arr_len] = tmp

def uninterlace_array_2bytes(arr, is_2nd, y):
	if(len(arr) != 16):
		raise Exception("len(arr) must be 16 bytes")
	
	arr_left = []
	arr_right = []
	
	if not is_2nd:
		shift_array_bytes(arr, 1)
		for i in range(4):
			arr_left.append(arr[i*4+2])
			arr_left.append(arr[i*4+3])
			arr_right.append(arr[i*4+0])
			arr_right.append(arr[i*4+1])
		
		#shift_array_bytes(arr_left, 0)
		px1 = arr_left[1]
		px2 = arr_left[3]
		px3 = arr_left[5]
		px0 = arr_left[7]
		arr_left[1] = px0
		arr_left[3] = px1
		arr_left[5] = px2
		arr_left[7] = px3
		
	else:
		shift_array_bytes(arr, -1)
		for i in range(4):
			arr_left.append(arr[i*4+0])
			arr_left.append(arr[i*4+1])
			arr_right.append(arr[i*4+2])
			arr_right.append(arr[i*4+3])
		#shift_array_bytes(arr_right, 0)
		px1 = arr_right[1]
		px2 = arr_right[3]
		px3 = arr_right[5]
		px0 = arr_right[7]
		arr_right[1] = px0
		arr_right[3] = px1
		arr_right[5] = px2
		arr_right[7] = px3
	
	return arr_left + arr_right
	
def copy_arr_to_arr_at_offset(offset, arr1, arr2):
	if len(arr1) < len(arr2):
		raise Exception("copy arr1 < arr2")
	
	if offset > len(arr1) - len(arr2):
		raise Exception("offset to big to copy")
	
	#print(offset, len(arr1), len(arr2))
	
	for i in range(len(arr2)):
		arr1[offset + i] = arr2[i]
	
def xy_to_yx(idx):
	x = idx % 16
	y = idx // 16
	return (y + x*16)
	



def idx_test(idx):
	#if idx*2 > 255:
	#	return idx*2 % 255
	#else:
	#	return idx*2 + 1
	
	#if (idx//16)*2 > 15:
	#	return ((idx//16)*2 % 15)*16 + 16 + idx % 16
	#else:
	#	return ((idx//16)*2 % 15)*16 + idx % 16
	
	#swap_arr = [+7, +5, +3, +1, -1, -3, -5, -7]
	#amt = 16
	#return idx + (amt - 1 - 2*(idx % amt))
	return idx


def make_test_image_256():
	global g_image_data
	arr = []
	for i in range(256*256):
		arr.append(i%64)
	g_image_data = arr
	
	

#def decode_scanline(y, width):
#	orig_scanline = g_image_data[2*y*width:2*(y+1)*width]
#	scanline_up = []
#	scanline_down = []
#	
#	for i in range(width):
#		scanline_up.append(orig_scanline[i*2])
#		scanline_down.append(orig_scanline[i*2+1])
#	
#	scanline = scanline_up + scanline_down
#	
#	for i in range(width // 16):
#		for j in range(4):
#			tmp = scanline[i*16 + j*2 + 1]
#			scanline[i*16 + j*2 + 1] = scanline[i*16 + j*2 + 8]
#			scanline[i*16 + j*2 + 8] = tmp
#			tmp = scanline[i*16 + j*2 + 1 + width]
#			scanline[i*16 + j*2 + 1 + width] = scanline[i*16 + j*2 + 8 + width]
#			scanline[i*16 + j*2 + 8 + width] = tmp
#	
#	return scanline
	

	
print(sys.argv[1])

texture_file = open(sys.argv[1], 'rb')
#texture_file.seek(2, 1)


(width, height, using_pallete) = parse_file(texture_file)

#width = 256
#height = 256
#make_test_image_256()


some_width = width * 2
some_height = (height + 1) // 2


im = Image.new('RGBA', (width, height))

#if len(g_pallete) == 256:
#	im = Image.new('RGBA', (some_width, some_height))
#else:
#	
print("Texture size %dx%d (using pallete: %s)" %(width, height, "yes" if using_pallete else "no"))

#print("Pallete:")
#for i in range(len(g_pallete)):
#	print("\t%d" % i, g_pallete[i])

if len(g_pallete) == 16:
	im_p = Image.new('RGBA', (4, 4))
	for i in range(16):
		im_p.putpixel((i % 4, i // 4), g_pallete[i])
	im_p.save("pallete.png", "png")
	
if len(g_pallete) == 256:
	im_p = Image.new('RGBA', (16, 16))
	for i in range(256):
		im_p.putpixel((i % 16, i // 16), g_pallete[i])
	im_p.save("pallete.png", "png")


if using_pallete:
	if len(g_pallete) == 16:
		for x in range(width):
			for y in range(height):
				idx = g_image_data[x // 2 + y*width // 2] & 0xF
				if x % 2 == 1:
					idx = (g_image_data[x // 2 + y*width // 2] & 0xF0) >> 4
				#print("(%d, %d) idx %d" % (x, y, idx))
				im.putpixel((x, y), g_pallete[idx])
	
	if len(g_pallete) == 256 and width < 128:
		for x in range(width):
			for y in range(height):
				idx = g_image_data[x + y*width]
				im.putpixel((x, y), g_pallete[idx])
				
	
	#also interlaced?
	if len(g_pallete) == 256 and (width == 256 or width == 128):
	
		#uninterlace data
		for y in range(height):
			for x in range(width // 32):
				for i in range(4):
					px2_tmp = (g_image_data[y*width + x*32 + i * 4 + 2], g_image_data[y*width + x*32 + i * 4 + 3])
					g_image_data[y*width + x*32 + i * 4 + 2] = g_image_data[y*width + x*32 + i * 4 + 2 + 14]
					g_image_data[y*width + x*32 + i * 4 + 3] = g_image_data[y*width + x*32 + i * 4 + 3 + 14]
					g_image_data[y*width + x*32 + i * 4 + 2 + 14] = px2_tmp[0]
					g_image_data[y*width + x*32 + i * 4 + 3 + 14] = px2_tmp[1]
		
		for y in range(some_height):
			for x in range(some_width // 16):
				arr_int = g_image_data[y*some_width + x*16: y*some_width + x*16 + 16]
				arr_unint = uninterlace_array_2bytes(arr_int, True if y % 4 > 1 else False, y)
				copy_arr_to_arr_at_offset(y*some_width + x*16, g_image_data, arr_unint)
		
		
		# scanline reorder require 2031 to 0123
		
		for y in range(height//4):
			#scanline = decode_scanline(y, width)
			for x in range(width):
				idx2 = g_image_data[x*2 + 0 + y*4*width]
				idx0 = g_image_data[x*2 + 1 + y*4*width]
				idx3 = g_image_data[x*2 + 0 + y*4*width + 2*width]
				idx1 = g_image_data[x*2 + 1 + y*4*width + 2*width]
				g_image_data[x*2 + 0 + y*4*width] = idx0
				g_image_data[x*2 + 1 + y*4*width] = idx1
				g_image_data[x*2 + 0 + y*4*width + 2*width] = idx2
				g_image_data[x*2 + 1 + y*4*width + 2*width] = idx3
		
		
		for y in range(height // 2):
			for x in range(width):
				idx1 = g_image_data[2*y*width + 2*x + 0]
				idx2 = g_image_data[2*y*width + 2*x + 1]
				im.putpixel((x,y*2 + 0), g_pallete[idx_test(idx1)])#(idx1,idx1,idx1,255)
				im.putpixel((x,y*2 + 1), g_pallete[idx_test(idx2)])#g_pallete[idx_test(idx2)]
					
		
	
else:
	for x in range(width):
		for y in range(height):
			pixel_value = (g_image_data[x*3 + 0 + y*width*3], g_image_data[x*3 + 1 + y*width*3], g_image_data[x*3 + 2 + y*width*3], 255)
			im.putpixel((x,y), pixel_value)




"""

for x in range(width):
	for y in range(height):
		pixel = im.getpixel((x, y))
		new_pixel = (pixel[3], pixel[1], int(math.sqrt(abs(255*255 - pixel[3]*pixel[3] - pixel[1]*pixel[1]))), 255)
		im.putpixel((x, y), new_pixel)

im.show()



"""

im.save( sys.argv[1] + '_processed.png', 'png')