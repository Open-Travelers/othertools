
def shift_array_bytes(arr, shift):
	arr_len = len(arr)
	if shift < 0:
		shift = arr_len - shift
	for i in range(arr_len - 1):
		tmp = arr[i]
		arr[i] = arr[(i+shift) % arr_len]
		arr[(i+shift) % arr_len] = tmp

test_arr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

print (test_arr)

shift_array_bytes(test_arr, -1)

print(test_arr)