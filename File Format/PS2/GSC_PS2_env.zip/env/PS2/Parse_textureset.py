from struct import unpack

file = open("TST0", "rb")
#file.seek(16)
type = 'type'

texture_amt = unpack("I", file.read(4))[0]
file.seek(4, 1)
print("texture_amt %d" % texture_amt)


def dump_chunk(file, id, size_of_chunk):
	data = file.read(size_of_chunk)
	f2 = open('TST0_dump\\' + str(id), "wb")
	f2.write(data)
	f2.close
	
for id in range(0, texture_amt):
	data = file.read(8)
	if (len(data)) < 8:
		break
	
	(texture_size, shift_to_texture) = unpack("II", data)
	print("id %d size %d" % (id, texture_size))
	file.seek(shift_to_texture, 1)
	dump_chunk(file, id, texture_size)
	

