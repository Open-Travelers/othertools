from struct import unpack

file = open("space.nus", "rb")
file.seek(8)
type = 'type'

def str_from_type(type):
	a = ''
	for i in range(4):
		a += chr((type >> i * 8) & 0xFF)
	return a

def dump_chunk(file, type, size_of_chunk):
	data = file.read(size_of_chunk - 8)
	f2 = open(str_from_type(type), "wb")
	f2.write(data)
	f2.close
	
	

while type is not None:
	data = file.read(4)
	if len(data) < 4:
		break
	
	data2 = file.read(4)
	type = unpack(">I", data)[0]
	size_of_chunk = unpack(">I", data2)[0]
	
	print(str_from_type(type), size_of_chunk)
	dump_chunk(file, type, size_of_chunk)
	#file.seek(size_of_chunk - 8, 1)
